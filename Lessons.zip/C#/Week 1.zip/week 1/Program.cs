﻿/*string ad, soyad;
Console.Write("Adınızı giriniz: ");
ad = Console.ReadLine();

Console.Write("Soyadınızı giriniz: ");
soyad = Console.ReadLine();

Console.WriteLine("Merhaba {0}, {1}", ad, soyad);

string adi;
adi = "Halil";
string soyadi = "Bekli";
int numara = 231030;
double ortalama = 4.0;
Console.WriteLine("Adı: {3}\n Soyadı: {2}\n Numara: {1}\n Ortalama: {0}", ortalama, numara, soyadi, adi);
Console.ReadKey();
// kullanıcıdan bir tuş inputu alır.

int sayi1, sayi2, toplam;
Console.Write("Sayı 1 gir: ");
sayi1 = Convert.ToInt32(Console.ReadLine());
Console.Write("Sayı 2 gir: ");
sayi2 = Convert.ToInt32(Console.ReadLine());
toplam = sayi1 + sayi2;

int carpim = sayi1 * sayi2;
double bolum = (double)sayi1 / sayi2;
Console.WriteLine("Sayı 1: {0}, Sayı 2: {1}\n Toplam: {2}\n Carpim: {3}\n Bolum: {4}", sayi1, sayi2, toplam, carpim, bolum);

int c = Console.Read();
Console.WriteLine(c);

// iki sayi alip bunlari karsilastir

int sayi_1, sayi_2;
Console.Write("1. Sayıyı gir: ");
sayi_1 = Convert.ToInt32(Console.ReadLine());
Console.Write("2. Sayıyı gir: ");
sayi_2 = Convert.ToInt32(Console.ReadLine());

if(sayi_1 == sayi_2)
{
    Console.WriteLine("İki sayı birbirine eşittir");
} else if(sayi_1 > sayi_2)
{
    Console.WriteLine("1. Sayı 2. Sayıdan büyüktür");
} else if (sayi_1 < sayi_2)
{
    Console.WriteLine("2. Sayı 1. Sayıdan büyüktür");
}

// döngüler
// 1 sayi iste. o sayiya kadar olan çift sayıları yazdır

int sayi3;
Console.WriteLine("Bir sayi gir: ");
sayi3 = Convert.ToInt32(Console.ReadLine());
int count = 0;

while (count < sayi3)
{
    if(count % 2 == 0 && count < sayi3)
    Console.WriteLine("{0} ", count);
    count++;
}
*/

//
int sayi4;
Console.WriteLine("Bir sayı gir: ");
sayi4 = Convert.ToInt32(Console.ReadLine());

for(int i = 0; i < sayi4; i++) // satır sayısı
{
    for(int j = 1; j < sayi4 - i; j++)
    {
        Console.Write(" ");
    }
    for(int k = 0; k < (i+1)*2 - 1; k++)
    {
        Console.Write("*");
    }
    Console.Write("\n");
}

/*
// diziler
int[] dizi = new int[10]; // dizi bir nesnedir. 'int[] dizi' dediğimizde diziyi tanımlamış, '= new int[]' ile de oluşturmuş oluyoruz.
for (int i = 0; i < dizi.Length; i++)
{
    dizi[i] = i;
}
for (int i = 0; i < dizi.Length; i++)
{
    Console.WriteLine("Dizinin {0}. elemanının değeri = {1} ", i+1, dizi[i]);
}
Console.ReadKey(); // eğer konsol hemen kapanıyorsa kapanmasını önlemek için

//

//
string[] dizi2 = { "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar" };
foreach (string s in dizi2)
{
    Console.WriteLine(s,"\n");
}
*/